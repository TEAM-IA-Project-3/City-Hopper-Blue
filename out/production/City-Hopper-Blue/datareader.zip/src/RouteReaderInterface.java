import java.util.List;

public interface RouteReaderInterface {
  List<String> getCities();
  List<RouteInterface> getRoutes();
}
